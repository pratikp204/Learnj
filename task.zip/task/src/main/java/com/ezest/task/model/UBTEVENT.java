/**
 * 
 */
package com.ezest.task.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

/**
 * @author srushti
 *
 */
@Entity
@Table(name="UBTEVENT")
public class UBTEVENT implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private String ID;
	
	@Column(name = "ACTOR")
	private String ACTOR;
	
	@Column(name = "ACTORMBOX")
	private String ACTORMBOX;
	
	@Column(name = "ACTORNAME")
	private String ACTORNAME;
	
	@Column(name = "VERB")
	private String VERB;
	
	@Column(name = "OBJECTID")
	private String OBJECTID;
	
	@Column(name = "OBJECTDESCRIPTION")
	private String OBJECTDESCRIPTION;
	
	@Column(name = "OBJECTTYPE")
	private String OBJECTTYPE;
	
	@Column(name = "EVENTTIMESTAMP")
	private Timestamp EVENTTIMESTAMP;
	
	@Column(name = "EVENTTIMESTORED")
	private Timestamp EVENTTIMESTORED;
	
	@Column(name = "SESSIONID")
	private String SESSIONID;
	
	@Column(name = "TPUSERID")
	private String TPUSERID;
	
	@Column(name = "TPSOURCESYSTEMID")
	private String TPSOURCESYSTEMID;
	
	@Column(name = "ACTIVITYTYPEID")
	private BigDecimal ACTIVITYTYPEID;
	
	@Column(name = "LEARNINGACTIVITYID")
	private BigDecimal LEARNINGACTIVITYID;
	
	@Column(name = "LEARNINGACTIVITYTYPEID")
	private BigDecimal LEARNINGACTIVITYTYPEID;
	
	@Column(name = "ATTEMPTID")
	private BigDecimal ATTEMPTID;
	
	@Column(name = "QUESTIONID")
	private String QUESTIONID;
	
	@Column(name = "APPLICATIONID")
	private BigDecimal APPLICATIONID;
	
	@Column(name = "LOCATIONTYPE")
	private String LOCATIONTYPE;
	
	@Column(name = "IPADDRESS")
	private String IPADDRESS;
	
	@Column(name = "USERAGENT",columnDefinition = "LONGTEXT")
	private String USERAGENT;
	
	@Column(name = "USERAUTHORITYID")
	private BigDecimal USERAUTHORITYID;
	
	@Column(name = "SOURCESYSTEMATTEMPTID")
	private String SOURCESYSTEMATTEMPTID;
	
	@Column(name = "STATEMENTVERSION")
	private String STATEMENTVERSION;
	
	@Column(name = "TECHNOLOGYPLATFORM",columnDefinition = "LONGTEXT")
	private String TECHNOLOGYPLATFORM;
	
	@Column(name = "SERVERDNS",columnDefinition = "LONGTEXT")
	private String SERVERDNS;
	
	@Column(name = "CREATEDTIMESTAMP")
	private Timestamp CREATEDTIMESTAMP;
	
	@Column(name = "LEARNINGUNITID")
	private BigDecimal LEARNINGUNITID;
	
	@Column(name = "ISPROCESSED",columnDefinition = "BIT", length = 1)
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean ISPROCESSED;
	/**
	 * @return the iD
	 */
	public String getID() {
		return ID;
	}
	/**
	 * @param iD the iD to set
	 */
	public void setID(String iD) {
		ID = iD;
	}
	/**
	 * @return the aCTOR
	 */
	public String getACTOR() {
		return ACTOR;
	}
	/**
	 * @param aCTOR the aCTOR to set
	 */
	public void setACTOR(String aCTOR) {
		ACTOR = aCTOR;
	}
	/**
	 * @return the aCTORMBOX
	 */
	public String getACTORMBOX() {
		return ACTORMBOX;
	}
	/**
	 * @param aCTORMBOX the aCTORMBOX to set
	 */
	public void setACTORMBOX(String aCTORMBOX) {
		ACTORMBOX = aCTORMBOX;
	}
	/**
	 * @return the aCTORNAME
	 */
	public String getACTORNAME() {
		return ACTORNAME;
	}
	/**
	 * @param aCTORNAME the aCTORNAME to set
	 */
	public void setACTORNAME(String aCTORNAME) {
		ACTORNAME = aCTORNAME;
	}
	/**
	 * @return the vERB
	 */
	public String getVERB() {
		return VERB;
	}
	/**
	 * @param vERB the vERB to set
	 */
	public void setVERB(String vERB) {
		VERB = vERB;
	}
	/**
	 * @return the oBJECTID
	 */
	public String getOBJECTID() {
		return OBJECTID;
	}
	/**
	 * @param oBJECTID the oBJECTID to set
	 */
	public void setOBJECTID(String oBJECTID) {
		OBJECTID = oBJECTID;
	}
	/**
	 * @return the oBJECTDESCRIPTION
	 */
	public String getOBJECTDESCRIPTION() {
		return OBJECTDESCRIPTION;
	}
	/**
	 * @param oBJECTDESCRIPTION the oBJECTDESCRIPTION to set
	 */
	public void setOBJECTDESCRIPTION(String oBJECTDESCRIPTION) {
		OBJECTDESCRIPTION = oBJECTDESCRIPTION;
	}
	/**
	 * @return the oBJECTTYPE
	 */
	public String getOBJECTTYPE() {
		return OBJECTTYPE;
	}
	/**
	 * @param oBJECTTYPE the oBJECTTYPE to set
	 */
	public void setOBJECTTYPE(String oBJECTTYPE) {
		OBJECTTYPE = oBJECTTYPE;
	}
	/**
	 * @return the eVENTTIMESTAMP
	 */
	public Timestamp getEVENTTIMESTAMP() {
		return EVENTTIMESTAMP;
	}
	/**
	 * @param eVENTTIMESTAMP the eVENTTIMESTAMP to set
	 */
	public void setEVENTTIMESTAMP(Timestamp eVENTTIMESTAMP) {
		EVENTTIMESTAMP = eVENTTIMESTAMP;
	}
	/**
	 * @return the eVENTTIMESTORED
	 */
	public Timestamp getEVENTTIMESTORED() {
		return EVENTTIMESTORED;
	}
	/**
	 * @param eVENTTIMESTORED the eVENTTIMESTORED to set
	 */
	public void setEVENTTIMESTORED(Timestamp eVENTTIMESTORED) {
		EVENTTIMESTORED = eVENTTIMESTORED;
	}
	/**
	 * @return the sESSIONID
	 */
	public String getSESSIONID() {
		return SESSIONID;
	}
	/**
	 * @param sESSIONID the sESSIONID to set
	 */
	public void setSESSIONID(String sESSIONID) {
		SESSIONID = sESSIONID;
	}
	/**
	 * @return the tPUSERID
	 */
	public String getTPUSERID() {
		return TPUSERID;
	}
	/**
	 * @param tPUSERID the tPUSERID to set
	 */
	public void setTPUSERID(String tPUSERID) {
		TPUSERID = tPUSERID;
	}
	/**
	 * @return the tPSOURCESYSTEMID
	 */
	public String getTPSOURCESYSTEMID() {
		return TPSOURCESYSTEMID;
	}
	/**
	 * @param tPSOURCESYSTEMID the tPSOURCESYSTEMID to set
	 */
	public void setTPSOURCESYSTEMID(String tPSOURCESYSTEMID) {
		TPSOURCESYSTEMID = tPSOURCESYSTEMID;
	}
	/**
	 * @return the aCTIVITYTYPEID
	 */
	public BigDecimal getACTIVITYTYPEID() {
		return ACTIVITYTYPEID;
	}
	/**
	 * @param aCTIVITYTYPEID the aCTIVITYTYPEID to set
	 */
	public void setACTIVITYTYPEID(BigDecimal aCTIVITYTYPEID) {
		ACTIVITYTYPEID = aCTIVITYTYPEID;
	}
	/**
	 * @return the lEARNINGACTIVITYID
	 */
	public BigDecimal getLEARNINGACTIVITYID() {
		return LEARNINGACTIVITYID;
	}
	/**
	 * @param lEARNINGACTIVITYID the lEARNINGACTIVITYID to set
	 */
	public void setLEARNINGACTIVITYID(BigDecimal lEARNINGACTIVITYID) {
		LEARNINGACTIVITYID = lEARNINGACTIVITYID;
	}
	/**
	 * @return the lEARNINGACTIVITYTYPEID
	 */
	public BigDecimal getLEARNINGACTIVITYTYPEID() {
		return LEARNINGACTIVITYTYPEID;
	}
	/**
	 * @param lEARNINGACTIVITYTYPEID the lEARNINGACTIVITYTYPEID to set
	 */
	public void setLEARNINGACTIVITYTYPEID(BigDecimal lEARNINGACTIVITYTYPEID) {
		LEARNINGACTIVITYTYPEID = lEARNINGACTIVITYTYPEID;
	}
	/**
	 * @return the aTTEMPTID
	 */
	public BigDecimal getATTEMPTID() {
		return ATTEMPTID;
	}
	/**
	 * @param aTTEMPTID the aTTEMPTID to set
	 */
	public void setATTEMPTID(BigDecimal aTTEMPTID) {
		ATTEMPTID = aTTEMPTID;
	}
	/**
	 * @return the qUESTIONID
	 */
	public String getQUESTIONID() {
		return QUESTIONID;
	}
	/**
	 * @param qUESTIONID the qUESTIONID to set
	 */
	public void setQUESTIONID(String qUESTIONID) {
		QUESTIONID = qUESTIONID;
	}
	/**
	 * @return the aPPLICATIONID
	 */
	public BigDecimal getAPPLICATIONID() {
		return APPLICATIONID;
	}
	/**
	 * @param aPPLICATIONID the aPPLICATIONID to set
	 */
	public void setAPPLICATIONID(BigDecimal aPPLICATIONID) {
		APPLICATIONID = aPPLICATIONID;
	}
	/**
	 * @return the lOCATIONTYPE
	 */
	public String getLOCATIONTYPE() {
		return LOCATIONTYPE;
	}
	/**
	 * @param lOCATIONTYPE the lOCATIONTYPE to set
	 */
	public void setLOCATIONTYPE(String lOCATIONTYPE) {
		LOCATIONTYPE = lOCATIONTYPE;
	}
	/**
	 * @return the iPADDRESS
	 */
	public String getIPADDRESS() {
		return IPADDRESS;
	}
	/**
	 * @param iPADDRESS the iPADDRESS to set
	 */
	public void setIPADDRESS(String iPADDRESS) {
		IPADDRESS = iPADDRESS;
	}
	/**
	 * @return the uSERAGENT
	 */
	public String getUSERAGENT() {
		return USERAGENT;
	}
	/**
	 * @param uSERAGENT the uSERAGENT to set
	 */
	public void setUSERAGENT(String uSERAGENT) {
		USERAGENT = uSERAGENT;
	}
	/**
	 * @return the uSERAUTHORITYID
	 */
	public BigDecimal getUSERAUTHORITYID() {
		return USERAUTHORITYID;
	}
	/**
	 * @param uSERAUTHORITYID the uSERAUTHORITYID to set
	 */
	public void setUSERAUTHORITYID(BigDecimal uSERAUTHORITYID) {
		USERAUTHORITYID = uSERAUTHORITYID;
	}
	/**
	 * @return the sOURCESYSTEMATTEMPTID
	 */
	public String getSOURCESYSTEMATTEMPTID() {
		return SOURCESYSTEMATTEMPTID;
	}
	/**
	 * @param sOURCESYSTEMATTEMPTID the sOURCESYSTEMATTEMPTID to set
	 */
	public void setSOURCESYSTEMATTEMPTID(String sOURCESYSTEMATTEMPTID) {
		SOURCESYSTEMATTEMPTID = sOURCESYSTEMATTEMPTID;
	}
	/**
	 * @return the sTATEMENTVERSION
	 */
	public String getSTATEMENTVERSION() {
		return STATEMENTVERSION;
	}
	/**
	 * @param sTATEMENTVERSION the sTATEMENTVERSION to set
	 */
	public void setSTATEMENTVERSION(String sTATEMENTVERSION) {
		STATEMENTVERSION = sTATEMENTVERSION;
	}
	/**
	 * @return the tECHNOLOGYPLATFORM
	 */
	public String getTECHNOLOGYPLATFORM() {
		return TECHNOLOGYPLATFORM;
	}
	/**
	 * @param tECHNOLOGYPLATFORM the tECHNOLOGYPLATFORM to set
	 */
	public void setTECHNOLOGYPLATFORM(String tECHNOLOGYPLATFORM) {
		TECHNOLOGYPLATFORM = tECHNOLOGYPLATFORM;
	}
	/**
	 * @return the sERVERDNS
	 */
	public String getSERVERDNS() {
		return SERVERDNS;
	}
	/**
	 * @param sERVERDNS the sERVERDNS to set
	 */
	public void setSERVERDNS(String sERVERDNS) {
		SERVERDNS = sERVERDNS;
	}
	/**
	 * @return the cREATEDTIMESTAMP
	 */
	public Timestamp getCREATEDTIMESTAMP() {
		return CREATEDTIMESTAMP;
	}
	/**
	 * @param cREATEDTIMESTAMP the cREATEDTIMESTAMP to set
	 */
	public void setCREATEDTIMESTAMP(Timestamp cREATEDTIMESTAMP) {
		CREATEDTIMESTAMP = cREATEDTIMESTAMP;
	}
	/**
	 * @return the lEARNINGUNITID
	 */
	public BigDecimal getLEARNINGUNITID() {
		return LEARNINGUNITID;
	}
	/**
	 * @param lEARNINGUNITID the lEARNINGUNITID to set
	 */
	public void setLEARNINGUNITID(BigDecimal lEARNINGUNITID) {
		LEARNINGUNITID = lEARNINGUNITID;
	}
	/**
	 * @return the iSPROCESSED
	 */
	/**
	 * @return the iSPROCESSED
	 */
	public boolean getISPROCESSED() {
		return ISPROCESSED;
	}
	/**
	 * @param iSPROCESSED the iSPROCESSED to set
	 */
	public void setISPROCESSED(boolean iSPROCESSED) {
		ISPROCESSED = iSPROCESSED;
	}
	
	
	
	
	
	
	
	



}
