/**
 * 
 */
package com.ezest.task.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ezest.task.model.UBTEVENT;

/**
 * @author srushti
 *
 */
public interface mailRepository extends JpaRepository<UBTEVENT, String> { 

	
	String aggregateQueryByQuestion = "select ID,count(*) from  UBTEVENT group by ID";
	@Query(value = aggregateQueryByQuestion, nativeQuery = true)
	public List<Object[]> getCount();

}
