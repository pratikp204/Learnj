/**
 * 
 */
package com.ezest.task.controller;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ezest.task.model.Email;
import com.ezest.task.service.EmailService;

/**
 * @author srushti
 *
 */
@Controller
public class emailController {

	@Autowired
	private EmailService emailService;

	final Logger logger = LoggerFactory.getLogger(emailController.class);

	/*
	 * @RequestMapping("/") public void getall() { Email email= new Email();
	 * email.setFirstName("srushti"); email.setLastName("chavan");
	 * email.setEmailAddress("vaishalichavan194@gmail.com");
	 * 
	 * List<Object[]> result = emailService.getCount(); Map<String,Long> map = null;
	 * Long count[]=new Long[100]; int i=0; if(result != null && !result.isEmpty()){
	 * map = new HashMap<String,Long>(); for (Object[] object : result) {
	 * map.put(((String)object[0]),(Long)object[1]); if((Long)object[1]>=1) {
	 * emailService.sendNotification(email); } } }
	 * 
	 * /* try { emailService.sendNotification(email); } catch(MailException e) {
	 * logger.info("falied "+e.getMessage()); }
	 * 
	 * 
	 * }
	 * 
	 */
	private JavaMailSender javaMailSender;

	@Autowired
	public emailController(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}

	@RequestMapping(value = "/get", method = RequestMethod.GET)
	public String sendNotification() throws MailException {

		SimpleMailMessage mail = new SimpleMailMessage();
		mail.setTo("srushtichavan007@gmail.com");
		mail.setFrom("srushtichavan007@gmail.com");
		mail.setSubject("subject");
		mail.setText("text count");
		List<Object[]> result = emailService.getCount();
		Map<String, BigInteger> map = null;
		BigInteger f = new BigInteger("1");
		if (result != null && !result.isEmpty()) {
			map = new HashMap<String, BigInteger>();
			for (Object[] object : result) {
				map.put((String) object[0], (BigInteger) object[1]);

				if (f.compareTo(((BigInteger) object[1])) == 0) {
					javaMailSender.send(mail);
				}
			}
		}
		// javaMailSender.send(mail);
		return "home";
	}

}
