/**
 * 
 */
package com.ezest.task.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.ezest.task.dao.mailRepository;
import com.ezest.task.model.Email;

/**
 * @author srushti
 *
 */
@Service
public class EmailService {
	private JavaMailSender javaMailSender;
	
	@Autowired
	private mailRepository mailrepo;
	
	@Autowired
	public EmailService(JavaMailSender javaMailSender)
	{
		this.javaMailSender=javaMailSender;
	}
	
	
	public void sendNotification(Email email)throws MailException
	{
		 SimpleMailMessage mail=new SimpleMailMessage();
	     mail.setTo(email.getEmailAddress());
	     mail.setFrom("srushtichavan007@gmail.com");
	     mail.setSubject("subject");
	     mail.setText("text");
	     
	     javaMailSender.send(mail);
	
	}
	
	public List<Object[]> getCount()
	{
	   return mailrepo.getCount();	
	}
	
	 /*  public void sendMail(final Email email){
	      SimpleMailMessage simpleMailMessage=new SimpleMailMessage();
	      simpleMailMessage.setSubject(email.getSubject());
	      simpleMailMessage.setFrom(email.getFrom());
	      simpleMailMessage.setTo(email.getTo());
	      simpleMailMessage.setText(email.getMessageText());
	      javaMailSender.send(simpleMailMessage);
	   }
	   public void sendMailWithAttachment(final Email email,
	         String filePath) throws Exception{
	      MimeMessage mimeMessage=javaMailSender.createMimeMessage();
	      MimeMessageHelper mimeMessageHelper=new
	         MimeMessageHelper(mimeMessage,true);
	      mimeMessageHelper.setSubject(email.getSubject());
	      mimeMessageHelper.setFrom(email.getFrom());
	      mimeMessageHelper.setTo(email.getTo());
	      mimeMessageHelper.setText(email.getMessageText());
	      FileSystemResource file=new FileSystemResource(new
	         File(filePath));
	      mimeMessageHelper.addAttachment("Sample File",file);
	      javaMailSender.send(mimeMessage);
	   }*/
}
