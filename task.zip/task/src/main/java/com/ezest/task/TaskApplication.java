package com.ezest.task;

import java.io.Serializable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskApplication implements Serializable {
	private static final long serialVersionUID = 1L;

	
	public static void main(String[] args) {
	//final Logger logger = LoggerFactory.getLogger(TaskApplication.class);
				//.getLogger(TaskApplication.class);
		SpringApplication.run(TaskApplication.class, args);
		
		
		
	     // emailService.sendMailWithAttachment(email, "./samplepic.jpg");
	}

}
