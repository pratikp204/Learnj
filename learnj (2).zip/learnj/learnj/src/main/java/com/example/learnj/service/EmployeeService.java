package com.example.learnj.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.learnj.model.Employee;
import com.example.learnj.repository.EmployeeRepository;

@Service
public class EmployeeService {

    @Autowired
    EmployeeRepository employeeRepository;

    public Employee save(Employee emp) {
        return employeeRepository.save(emp);
    }

    public List<Employee> findAll(){
        return (List<Employee>) employeeRepository.findAll();
    }

    public Employee findById(Long empid) {
        return employeeRepository.findById(empid).orElse(null);
    }

    public void delete(Employee emp) {
        employeeRepository.delete(emp);
    }

}