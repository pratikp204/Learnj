package com.example.learnj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnjApplicationTests {

	@Test
	void contextLoads() {
	}

}
